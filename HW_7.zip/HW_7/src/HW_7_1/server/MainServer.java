package HW_7_1.server;

public class MainServer {
    public static void main(String[] args) {
        new Server();
    }
}
