package HW_6.Server;

public class StartServer {
    public static void main(String[] args) {
        new ServerTest();
    }
}